import { Component, OnInit } from '@angular/core';
import { EvaluacionService } from '../evaluacion.service';
import { Evaluacion } from '../../shared/models/evaluacion.model';

@Component({
  selector: 'app-lista-evaluaciones',
  templateUrl: './lista-evaluaciones.component.html',
  styleUrls: ['./lista-evaluaciones.component.css']
})
export class ListaEvaluacionesComponent implements OnInit {

  evaluaciones: Evaluacion[] = [];
  cargando = true;

  constructor(private evaluacionService: EvaluacionService) {}

  ngOnInit(): void {
    this.cargarEvaluaciones();
  }

  eliminarEvaluacion(id: number): void {
    if (!confirm('¿Eliminar esta evaluación?')) return;
    this.evaluacionService.deleteEvaluacion(id).subscribe({
      next: () => this.cargarEvaluaciones()
    });
  }
  getBadgeStyle(estado: string | undefined): any {
    const estilos: { [key: string]: any } = {
      'Realizada': { background: '#d4edda', color: '#155724' },
      'Enviada':   { background: '#e0f7fa', color: '#0097a7' },
    };
    return estilos[estado || ''] || { background: '#f0f0f0', color: '#6b7280' };
  }

  evaluacionesFiltradas: Evaluacion[] = [];
  busqueda = '';

  cargarEvaluaciones(): void {
    this.evaluacionService.getEvaluaciones().subscribe({
      next: (data) => {
        // Ordenar por id descendente: los más recientes primero
        this.evaluaciones = data.sort((a, b) => (b.id || 0) - (a.id || 0));
        this.evaluacionesFiltradas = this.evaluaciones;
        this.cargando = false;
      },
      error: () => { this.cargando = false; }
    });
  }

  onBusqueda(texto: string): void {
    this.busqueda = texto;
    this.evaluacionesFiltradas = this.evaluaciones.filter(e =>
      !texto ||
      e.contacto?.toLowerCase().includes(texto.toLowerCase()) ||
      e.categoria?.toLowerCase().includes(texto.toLowerCase()) ||
      e.realizada_por?.toLowerCase().includes(texto.toLowerCase())
    );
  }
}